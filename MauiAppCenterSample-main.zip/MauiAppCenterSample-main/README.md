[![YouTube Video Views](https://img.shields.io/youtube/views/Bz1XLecJlXc?style=social)](https://www.youtube.com/watch?v=Bz1XLecJlXc&list=PLfbOp004UaYWu-meDkRN6_Y1verl96npI)

# .NET MAUI AppCenter Sample
Sample code to demonstrate how to get started with .NET MAUI and App Center
